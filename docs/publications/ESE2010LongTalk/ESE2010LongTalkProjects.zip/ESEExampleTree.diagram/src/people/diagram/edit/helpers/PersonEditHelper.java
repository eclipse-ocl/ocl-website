package people.diagram.edit.helpers;

/**
 * @generated
 */
public class PersonEditHelper extends PeopleBaseEditHelper {
}
