package people.diagram.edit.helpers;

/**
 * @generated
 */
public class UniverseEditHelper extends PeopleBaseEditHelper {
}
