package badsimple.states;

public class Machine
{
    public interface State
    {
        public void doSTART();
        public void doSTOP();

        enum STATES
        {
            STATE_Start,
            STATE_Stop
        }
    }

    private final State[] states = new State[] {
        new Start(this),
        new Stop(this)
    };

    private State state;

    public Machine() {
        setState(State.STATES.STATE_org.eclipse.emf.ecore.impl.DynamicEObjectImpl@d35cfe (eClass: org.eclipse.emf.ecore.impl.EClassImpl@7e3fb6 (name: OclInvalid_Class) (instanceClassName: null) (abstract: false, interface: false)));
    }

    public void setState(State.STATES state) {
        this.state = states[state.ordinal()];
    }

    public void doSTART() { state.doSTART(); }
    public void doSTOP() { state.doSTOP(); }
}    
