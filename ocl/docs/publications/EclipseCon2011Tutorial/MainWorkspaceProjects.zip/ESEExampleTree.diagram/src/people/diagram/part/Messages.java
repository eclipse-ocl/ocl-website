package people.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	 * @generated
	 */
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Messages() {
	}

	/**
	 * @generated
	 */
	public static String PeopleCreationWizardTitle;

	/**
	 * @generated
	 */
	public static String PeopleCreationWizard_DiagramModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String PeopleCreationWizard_DiagramModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String PeopleCreationWizard_DomainModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String PeopleCreationWizard_DomainModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String PeopleCreationWizardOpenEditorError;

	/**
	 * @generated
	 */
	public static String PeopleCreationWizardCreationError;

	/**
	 * @generated
	 */
	public static String PeopleCreationWizardPageExtensionError;

	/**
	 * @generated
	 */
	public static String PeopleDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String PeopleDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String PeopleDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	 * @generated
	 */
	public static String PeopleDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	 * @generated
	 */
	public static String PeopleDocumentProvider_isModifiable;

	/**
	 * @generated
	 */
	public static String PeopleDocumentProvider_handleElementContentChanged;

	/**
	 * @generated
	 */
	public static String PeopleDocumentProvider_IncorrectInputError;

	/**
	 * @generated
	 */
	public static String PeopleDocumentProvider_NoDiagramInResourceError;

	/**
	 * @generated
	 */
	public static String PeopleDocumentProvider_DiagramLoadingError;

	/**
	 * @generated
	 */
	public static String PeopleDocumentProvider_UnsynchronizedFileSaveError;

	/**
	 * @generated
	 */
	public static String PeopleDocumentProvider_SaveDiagramTask;

	/**
	 * @generated
	 */
	public static String PeopleDocumentProvider_SaveNextResourceTask;

	/**
	 * @generated
	 */
	public static String PeopleDocumentProvider_SaveAsOperation;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_WizardTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	 * @generated
	 */
	public static String PeopleNewDiagramFileWizard_CreationPageName;

	/**
	 * @generated
	 */
	public static String PeopleNewDiagramFileWizard_CreationPageTitle;

	/**
	 * @generated
	 */
	public static String PeopleNewDiagramFileWizard_CreationPageDescription;

	/**
	 * @generated
	 */
	public static String PeopleNewDiagramFileWizard_RootSelectionPageName;

	/**
	 * @generated
	 */
	public static String PeopleNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	 * @generated
	 */
	public static String PeopleNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	 * @generated
	 */
	public static String PeopleNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	 * @generated
	 */
	public static String PeopleNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	 * @generated
	 */
	public static String PeopleNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	 * @generated
	 */
	public static String PeopleNewDiagramFileWizard_InitDiagramCommand;

	/**
	 * @generated
	 */
	public static String PeopleNewDiagramFileWizard_IncorrectRootError;

	/**
	 * @generated
	 */
	public static String PeopleDiagramEditor_SavingDeletedFile;

	/**
	 * @generated
	 */
	public static String PeopleDiagramEditor_SaveAsErrorTitle;

	/**
	 * @generated
	 */
	public static String PeopleDiagramEditor_SaveAsErrorMessage;

	/**
	 * @generated
	 */
	public static String PeopleDiagramEditor_SaveErrorTitle;

	/**
	 * @generated
	 */
	public static String PeopleDiagramEditor_SaveErrorMessage;

	/**
	 * @generated
	 */
	public static String PeopleElementChooserDialog_SelectModelElementTitle;

	/**
	 * @generated
	 */
	public static String ModelElementSelectionPageMessage;

	/**
	 * @generated
	 */
	public static String ValidateActionMessage;

	/**
	 * @generated
	 */
	public static String People1Group_title;

	/**
	 * @generated
	 */
	public static String Person1CreationTool_title;

	/**
	 * @generated
	 */
	public static String Person1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String PersonChildren2CreationTool_title;

	/**
	 * @generated
	 */
	public static String PersonChildren2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String PersonParents3CreationTool_title;

	/**
	 * @generated
	 */
	public static String PersonParents3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String CommandName_OpenDiagram;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Person_2001_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Person_2001_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_PersonChildren_4002_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_PersonChildren_4002_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Universe_1000_links;

	/**
	 * @generated
	 */
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnexpectedValueType;

	/**
	 * @generated
	 */
	public static String AbstractParser_WrongStringConversion;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnknownLiteral;

	/**
	 * @generated
	 */
	public static String MessageFormatParser_InvalidInputError;

	/**
	 * @generated
	 */
	public static String PeopleModelingAssistantProviderTitle;

	/**
	 * @generated
	 */
	public static String PeopleModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
